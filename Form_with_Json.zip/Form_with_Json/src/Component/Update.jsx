const Update=()=>{
    return(
        <>
<h1>This is Update Pagwe</h1>
        </>
    )
}
export default Update;