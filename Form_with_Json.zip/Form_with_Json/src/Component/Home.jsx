const Home=()=>{
    return(
        <>
           <h1>This is Home Page</h1>
           <p>A paragraph is a series of sentences that are organized and coherent,
            and are all related to a single topic. Almost every piece of writing you 
            do that is longer than a few sentences should be organized into paragraphs.</p>
        </>
    )
}
export default Home;