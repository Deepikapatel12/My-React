import Comp2 from "./Comp2";

const Comp1=()=>{
    return(
        <>
            <h1>Component 1:</h1>
            <Comp2/>
        </>
    )
}
export default Comp1;