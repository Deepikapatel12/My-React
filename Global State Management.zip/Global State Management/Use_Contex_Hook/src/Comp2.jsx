import Comp3 from "./Comp3";

const Comp2=()=>{
    return(
        <>
            <h1>Component 2:</h1>
            <Comp3/>
        </>
    )
}
export default Comp2;