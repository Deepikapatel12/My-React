import Comp5 from "./comp5";

const Comp4=()=>{
    return(
        <>
            <h1>Component 2:</h1>
            <Comp5/>
        </>
    )
}
export default Comp4;