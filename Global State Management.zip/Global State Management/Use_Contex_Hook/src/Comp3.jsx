import Comp4 from "./Comp4";

const Comp3=()=>{
    return(
        <>
            <h1>Component 2:</h1>
            <Comp4/>
        </>
    )
}
export default Comp3;