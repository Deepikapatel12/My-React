import Cybrom from "./Cybrom";

const Collage=()=>{
    return(
        <>
            <h1>Wellcome to collage</h1>
            <Cybrom/>
        </>
    )
}
export default Collage;